import pygame, sys, random
from pygame.locals import *

# Configurar Pygame
pygame.init()
relojPrincipal = pygame.time.Clock()

# Medidas de la ventana, y la configuración para la superficie.
ANCHOVENTANA = 600
ALTOVENTANA = 700
superficieVentana = pygame.display.set_mode((ANCHOVENTANA, ALTOVENTANA), 0, 32)
pygame.display.set_caption('Comete todo')

# Colores a utilizar.
NEGRO = (0, 0, 0)
VERDE = (0, 255, 0)
BLANCO = (255, 255, 255)

# Estableciendo a la comida y al jugador.
contadorDeComida = 0
NUEVACOMIDA = 40
TAMAÑOCOMIDA = 20
jugador = pygame.Rect(300, 100, 50, 50)
comidas = []
for i in range(60):
    comidas.append(pygame.Rect(random.randint(0, ANCHOVENTANA - TAMAÑOCOMIDA), random.randint(0, ALTOVENTANA - TAMAÑOCOMIDA), TAMAÑOCOMIDA, TAMAÑOCOMIDA))

# Estructuras de datos de los movimientos.
moverseIzquierda = False
moverseDerecha = False
moverseArriba = False
moverseAbajo = False

VELOCIDAD = 10


# Evento y manejo del usuario sobre el cuadrado.
while True:
    # Bucle del juego.
    for evento in pygame.event.get():
        if evento.type == QUIT:
            pygame.quit()
            sys.exit()
        # Movimiento que puede llegar hacer el usario sobre el cuadrado.
        if evento.type == KEYDOWN:
            if evento.key == K_LEFT or evento.key == ord('a'):
                moverseDerecha = False
                moverseIzquierda = True
            if evento.key == K_RIGHT or evento.key == ord('d'):
                moverseIzquierda = False
                moverseDerecha = True
            if evento.key == K_UP or evento.key == ord('w'):
                moverseAbajo = False
                moverseArriba = True
            if evento.key == K_DOWN or evento.key == ord('s'):
                moverseArriba = False
                moverseAbajo = True
        if evento.type == KEYUP:
            if evento.key == K_ESCAPE:
                pygame.quit()
                sys.exit()
            if evento.key == K_LEFT or evento.key == ord('a'):
                moverseIzquierda = False
            if evento.key == K_RIGHT or evento.key == ord('d'):
                moverseDerecha = False
            if evento.key == K_UP or evento.key == ord('w'):
                moverseArriba = False
            if evento.key == K_DOWN or evento.key == ord('s'):
                moverseAbajo = False
            if evento.key == ord('x'):
                jugador.top = random.randint(0, ALTOVENTANA - jugador.height)
                jugador.left = random.randint (0, ANCHOVENTANA - jugador.width)

        if evento.type == MOUSEBUTTONUP:
            comidas.append(pygame.Rect(evento.pos[0], evento.pos[1], TAMAÑOCOMIDA, TAMAÑOCOMIDA))

    # Aumentando la comida.
    contadorDeComida += 1
    if contadorDeComida >= NUEVACOMIDA:
        contadorDeComida = 0
        comidas.append(pygame.Rect(random.randint(0, ANCHOVENTANA - TAMAÑOCOMIDA), random.randint(0, ALTOVENTANA - TAMAÑOCOMIDA), TAMAÑOCOMIDA, TAMAÑOCOMIDA))

    # Superficie de la ventana.
    superficieVentana.fill(NEGRO)

    # Desplazando al jugador por toda la ventana
    if moverseAbajo and jugador.bottom < ALTOVENTANA:
        jugador.bottom += VELOCIDAD
    if moverseArriba and jugador.top > 0:
        jugador.top -= VELOCIDAD
    if moverseIzquierda and jugador.left > 0:
        jugador.left -= VELOCIDAD
    if moverseDerecha and jugador.right < ANCHOVENTANA:
        jugador.right += VELOCIDAD

    # Dibujar al jugador sobre la superficie
    pygame.draw.rect(superficieVentana, BLANCO, jugador)

    # Colision entre el jugador y la comida.
    for comida in comidas[:]:
        if jugador.colliderect(comida):
            comidas.remove(comida)

    # Dibujar la comida en la superficie.
    for i in range(len(comidas)):
        pygame.draw.rect(superficieVentana, VERDE, comidas[i])

    # Representar el programa sobre la pantalla y la funcioón tick.
    pygame.display.update()
    relojPrincipal.tick(40)
    
