def esPar(numero):
    return numero % 2 == 0

def esImpar(numero):
    return numero % 2 ==  

print('Ingrese un numero para saber si es par o impar')
numero = int(input("Número: "))

if numero == esPar(numero):
    print("Tu número ",numero," resuelto ser Par")
else:
    print("Tu número ",numero," resuelto ser Impar")

assert esImpar(42) == False
assert esImpar(9999) == True
assert esImpar(-10) == False
assert esImpar(-11) == True
assert esImpar(3.1415) == False
assert esPar(42) == True
assert esPar(9999) == False
assert esPar(-10) == True
assert esPar(-11) == False
assert esPar(3.1415) == False
             



    
