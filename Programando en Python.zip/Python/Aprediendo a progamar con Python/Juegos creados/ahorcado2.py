import random
IMÁGENES_AHORCADO = ['''

  +---+
  |   |
      |
      |
      |
      |
=========''', '''

  +---+
  |   |
  O   |
      |
      |
      |
=========''', '''

  +---+
  |   |
  O   |
  |   |
      |
      |
=========''', '''

  +---+
  |   |
  O   |
 /|   |
      |
      |
=========''', '''

  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========''', '''

  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========''', '''

  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========''', '''
  +---+
  |   |
 [O   |
 /|\  |
 / \  |
      |
=========''', '''
  +---+
  |   |
 [O]  |
 /|\  |
 / \  |
      |
=========''']
palabras = {'fraseDelLosEspeciales':'dehabersabido alexmaricon nazi cacarlos hastayo meincluyo chepaconfiltro verga mitio pendejoalex yaputamierdademierda filtrosa cacahuate culion minitas pechito garbanzo negro giusseppe tonybola buitre meteoro terrorista negga pechodechifle'.split(),
'partesDelCuerpo':'verga chepa tetas pectorales gluteos lastetasdebryan huevosflacidos patasdegallina'.split(),
'Animales':'bryan alex carlos luis omar joseph amangandi moises arevalo fernando saraguro mendieta maldonado alessandro zambrano sacco rosales alexis ortega aguirre kevin elian valarezo guaman'.split(),
'frutas':'manzana naranja limon lima per sandia uva pomelo cereza banana melon mango fresa tomate'.split()}

def obtenerPalabraAlAzar(diccionarioDePalabras):
    #Esta función devuelve una cadena al azar de la lista de cadenas pasada como argumento.
    #Primero, elige una clave al azar del diccionario:
    claveDePalabras = random.choice(list(diccionarioDePalabras.keys()))

    #Segundo, elige una palabra aleatoria de la lista correspondiente a la clave en el diccionario:
    indiceDePalabra = random.randint(0,len(diccionarioDePalabras[claveDePalabras]) - 1)

    return [diccionarioDePalabras[claveDePalabras][indiceDePalabra],[claveDePalabras]]

def mostrarTablero(IMÁGENES_AHORCADO, letrasIncorrectas, letrasCorrectas, palabraSecreta):
    print(IMÁGENES_AHORCADO[len(letrasIncorrectas)])
    print()

    print('Letras incorrectas:', end=' ')
    for letra in letrasIncorrectas:
        print(letra, end=' ')
    print()

    espaciosVacios = '_' * len(palabraSecreta)

    for i in range(len(palabraSecreta)): # El juador debe completar los espacios vacíos con las letras adivinas.
        if palabraSecreta[i] in letrasCorrectas:
            espaciosVacios = espaciosVacios[:i] + palabraSecreta[i] + espaciosVacios[i+1:]

    for letra in espaciosVacios: # Mostrar la palabra secreta con espacios entre cada letra
        print(letra, end=' ')
    print()

def obtenerIntento(letrasProbadas):
    # Devuelve la letra ingresada por el jugador. Verifica que el jugador ha ingresado solo una letra, y no otra cosa. 
    while True:
        print('Adivina una letra.')
        intento = input()
        intento = intento.lower()
        if len(intento) != 1:
            print('Por favor, introduce una letra.')
        elif intento in letrasProbadas:
            print('Ya has probado esa letra. Elige otra.')
        elif intento not in 'abcdefghijklmnñopqrstuvwxyz':
            print('Por favor ingresa una LETRA.')
        else:
            return intento

def jugarDeNuevo():
    # Esta función devuelve True si el jugador quiere volver a jugar, en caso contrario devuelve False.
    print('¿Quieres jugar de nuevo? (sí o no)')
    return input().lower().startswith('s')


print('A H O R C A D O')
letrasIncorrectas = ''
letrasCorrectas = ''
palabraSecreta, claveSecreta = obtenerPalabraAlAzar(palabras)
juegoTerminado = False

while True:
    print('La palabra secreta pertenece al conjunto ' + str(claveSecreta))
    mostrarTablero(IMÁGENES_AHORCADO, letrasIncorrectas, letrasCorrectas, palabraSecreta)

    # Permite al jugador escribir una letra.
    intento = obtenerIntento(letrasIncorrectas + letrasCorrectas)

    if intento in palabraSecreta:
        letrasCorrectas = letrasCorrectas + intento

        # Verifica si el jugador ha ganado.
        encontradoTodasLasLetras = True
        for i in range(len(palabraSecreta)):
            if palabraSecreta[i] not in letrasCorrectas:
                encontradoTodasLasLetras = False
                break
        if encontradoTodasLasLetras:
            print('¡Sí! ¡La palabra secreta era mismo "' + palabraSecreta + '"! ¡Has ganado!')
            juegoTerminado = True
    else:
        letrasIncorrectas = letrasIncorrectas + intento

        # Comprobar si el jugador no ha podido adivinar la palabra secreta.
        if len(letrasIncorrectas) == len(IMÁGENES_AHORCADO) - 1:
            mostrarTablero(IMÁGENES_AHORCADO, letrasIncorrectas, letrasCorrectas, palabraSecreta)
            print('¡Te has quedado sin intentos!\nDespués de ' + str(len(letrasIncorrectas)) + ' intentos fallidos y ' + str(len(letrasCorrectas)) + ' aciertos, la palabra era "' + palabraSecreta + '"')
            juegoTerminado = True

    # Preguntar al jugador si quiere jugar de nuevo (pero solo si el juego a terminado)
    if juegoTerminado:
        if jugarDeNuevo():
            letrasIncorrectas = ''
            letrasCorrectas = ''
            juegoTerminado = False
            palabraSecreta, claveSecreta = obtenerPalabraAlAzar(palabras)
        else:
            break
