#Maquina de chiste

respuesta1 = 'No'

print ('Hola como te llamas?')
nombre = input()
print ('¡Mucho gusto ' + nombre + '!')
print ('Te cuento, soy una maquina de chiste. ¿Quieres que te cuente uno?')
input()
print ('¿Qué hace Alex con una verga?')
input()
print ('Las reparte en 19, de 12 y de 17 JAJAJAJAJA')
print ()
print ('Tengo otro, te va gustar')
input()
print ('¿Sabes cual es el sinonimo de Bryan?')
input()
print ('Manitas locas')





