import pygame, sys, random
from pygame.locals import *

def verifSuperposicionRects(rect1, rect2):
    for a, b in [(rect1, rect2), (rect2, rect1)]:
        # Verifica si las esquina de "a" se encuentran dentro de "b"
        if ((puntoDentroDeRect(a.left, a.top, b)) or
            (puntoDentroDeRect(a.left, a.bottom, b)) or
            (puntoDentroDeRect(a.right, a.top, b)) or
            (puntoDentroDeRect(a.right, a.bottom, b))):
            return True

    return False

def puntoDentroDeRect(x, y, rect):
    if (x > rect.left) and (x < rect.right) and (y > rect.top) and (y < rect.bottom):
        return True
    else:
        return False
    

# Configurar pygame
pygame.init()
relojPrincipal = pygame.time.Clock()

# Establece la ventana.
ANCHOVENTANA = 670
ALTOVENTANA = 700
superficieVentana = pygame.display.set_mode((ANCHOVENTANA, ALTOVENTANA), 0, 32)
pygame.display.set_caption('Entradas')

# Establece las variables de dirección
ABAJOIZQUIERDA = 1
ABAJODERECHA = 3
ARRIBAIZQUIERDA = 7
ARRIBADERECHA = 9

# Configurar los colores
NEGRO = (0, 0, 0)
VERDE = (0, 255, 0)
BLANCO = (255, 255, 255)

# Configurar estructura de datos del jugador y la comida
contadorDeComida = 0
NUEVACOMIDA = 40
TAMAÑOCOMIDA = 20
jugador = {'rect':pygame.Rect(300, 100, 50, 50), 'dir':ARRIBAIZQUIERDA}
comidas = []
for i in range(60):
    comidas.append(pygame.Rect(random.randint(0, ANCHOVENTANA - TAMAÑOCOMIDA), random.randint(0, ALTOVENTANA - TAMAÑOCOMIDA), TAMAÑOCOMIDA, TAMAÑOCOMIDA))

# Configurar variables de movimiento
moverseIzquierda = False
moverseDerecha = False
moverseArriba = False
moverseAbajo = False

VELOCIDADMOVIMIENTO = 10


# Ejecutar el bucle del juego
while True:
    # Comprobar eventos
    for evento in pygame.event.get():
        if evento.type == QUIT:
            pygame.quit()
            sys.exit()
        if evento.type == KEYDOWN:
            # Cambiar las variables del teclado
            if evento.key == K_LEFT or evento.key == ord('a'):
                moverseDerecha = False
                moverseIzquierda = True
            if evento.key == K_RIGHT or evento.key == ord('d'):
                moverseIzquierda = False
                moverseDerecha = True
            if evento.key == K_UP or evento.key == ord('w'):
                moverseAbajo = False
                moverseArriba = True
            if evento.key == K_DOWN or evento.key == ord('s'):
                moverseArriba = False
                moverseAbajo = True
        if evento.type == KEYUP:
            if evento.key == K_ESCAPE:
                pygame.quit()
                sys.exit()
            if evento.key == K_LEFT or evento.key == ord('a'):
                moverseIzquierda = False
            if evento.key == K_RIGHT or evento.key == ord('d'):
                moverseDerecha = False
            if evento.key == K_UP or evento.key == ord('w'):
                moverseArriba = False
            if evento.key == K_DOWN or evento.key == ord('s'):
                moverseAbajo = False
            if evento.key == ord('x'):
                jugador.top = random.randint(0, ALTOVENTANA - jugador.height)
                jugador.left = random.randint(0, ANCHOVENTANA - jugador.width)
                
        if evento.type == MOUSEBUTTONUP:
            comidas.append(pygame.Rect(evento.pos[0], evento.pos[1], TAMAÑOCOMIDA, TAMAÑOCOMIDA))

    # Mueve la estructura de datos rebotín
    if jugador['dir'] == ABAJOIZQUIERDA:
        jugador['rect'].left -= VELOCIDADMOVIMIENTO
        jugador['rect'].top += VELOCIDADMOVIMIENTO
    if jugador['dir'] == ABAJODERECHA:
        jugador['rect'].left += VELOCIDADMOVIMIENTO
        jugador['rect'].top += VELOCIDADMOVIMIENTO
    if jugador['dir'] == ARRIBAIZQUIERDA:
        jugador['rect'].left -= VELOCIDADMOVIMIENTO
        jugador['rect'].top -= VELOCIDADMOVIMIENTO
    if jugador['dir'] == ARRIBADERECHA:
        jugador['rect'].left += VELOCIDADMOVIMIENTO
        jugador['rect'].top -= VELOCIDADMOVIMIENTO

    # Verifica si rebotín se movió fuera de la ventana
    if jugador['rect'].top < 0:
        # Rebotín se movió por encima de la ventana
        if jugador['dir'] == ARRIBAIZQUIERDA:
            jugador['dir'] = ABAJOIZQUIERDA
        if jugador['dir'] == ARRIBADERECHA:
            jugador['dir'] = ABAJODERECHA
    if jugador['rect'].bottom > ALTOVENTANA:
        # Rebotín fue mas abajo de la ventana
        if jugador['dir'] == ABAJOIZQUIERDA:
            jugador['dir'] = ARRIBAIZQUIERDA
        if jugador['dir'] == ABAJODERECHA:
            jugador['dir'] = ARRIBADERECHA
    if jugador['rect'].left < 0:
        # Rebotín se paso del lado izquierdo de la pantalla.
        if jugador['dir'] == ABAJOIZQUIERDA:
            jugador['dir'] = ABAJODERECHA
        if jugador['dir'] == ARRIBAIZQUIERDA:
            jugador['dir'] = ARRIBADERECHA
    if jugador['rect'].right > ANCHOVENTANA:
        # Rebotín se paso del lado derecho de la pantalla.
        if jugador['dir'] == ABAJODERECHA:
            jugador['dir'] = ABAJOIZQUIERDA
        if jugador['dir'] == ARRIBADERECHA:
            jugador['dir'] = ARRIBAIZQUIERDA

    contadorDeComida += 10
    if contadorDeComida >= NUEVACOMIDA:
        # Agregar nueva comida
        contadorDeComida = 0
        comidas.append(pygame.Rect(random.randint(0, ANCHOVENTANA - TAMAÑOCOMIDA), random.randint(0, ALTOVENTANA - TAMAÑOCOMIDA), TAMAÑOCOMIDA, TAMAÑOCOMIDA))

    # Dibujar el fondo negro sobre la superficie
    superficieVentana.fill(NEGRO)

    # Mover al jugador
    if moverseAbajo and jugador.bottom < ALTOVENTANA:
        jugador.top += VELOCIDADMOVIMIENTO
    if moverseArriba and jugador.top > 0:
        jugador.top -= VELOCIDADMOVIMIENTO
    if moverseIzquierda and jugador.left > 0:
        jugador.left -= VELOCIDADMOVIMIENTO
    if moverseDerecha and jugador.right < ANCHOVENTANA:
        jugador.right += VELOCIDADMOVIMIENTO

    # Dibujar al jugador sobre la superficie
    pygame.draw.rect(superficieVentana, BLANCO, jugador['rect'])

    # Comprobar si el jugador ha intersectado alguno de los cuadrados de comida.
    for comida in comidas[:]:
        if jugador.colliderect(comida):
            comidas.remove(comida)

    # Dibujar comida.
    for i in range(len(comidas)):
        pygame.draw.rect(superficieVentana, VERDE, comidas[i])

    # Dibujar la ventana sobre la pantalla.
    pygame.display.update()
    relojPrincipal.tick(40)
    
        
            
