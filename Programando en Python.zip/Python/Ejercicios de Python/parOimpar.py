print('Ingrese un numero para saber si es par o impar')
numero = int(input("Número: "))


if numero == 0:
    print("Tu número resulto ser par")
elif numero % 2 == 0 or numero == esPar:
    print("Tu numero ",numero," es Par")
else:
    numero == esImpar
    print("Tu numero ",numero," es impar")




    
