import sys

def convertirACelsius(gradosFahrenheit):
    return (gradosFahrenheit - 32) * (5 / 9)


def convertirAFahrenheit(gradosCelsius):
    return gradosCelsius * (9 / 5) + 32

def asegurarSalida():
    print('¿Seguro que queires salir? (Sí/No)')
    return input().lower().startswith('s')

assert convertirACelsius(0) == -17.77777777777778
assert convertirACelsius(180) == 82.22222222222223
assert convertirAFahrenheit(0) == 32
assert convertirAFahrenheit(100) == 212
assert convertirACelsius(convertirAFahrenheit(15)) == 15

# Los errores de redondeo causan una ligera discrepancia
assert convertirACelsius(convertirAFahrenheit(42)) == 42.00000000000001

eleccion = 0

#Bienvenida del programa.
print('Hola soy un convertidor de Celsius a Fahrenheit')
print('¡Te gustaria saber como funciona?')
respusta1 = input()
print('Vale, pero antes dime las unidades de Fahrenheit y Celius que deseas convertir')

#Eleccion de grados Fahrenheit o de Celsius
gradosFahrenheit = int(input("Ingrese el valor de Faherenheit: "))
gradosCelsius = int(input("Ingrese el valor Celsius: "))
print('Ahora sí, procede a elegir una de las siguientes opciones')


#Bucle del programa conversión.
while eleccion != 4:
    print(''''
          1) Convertir a Celsius
          2) Convertir a Fahrenheit
          3) Cambiar Valores
          4) Salir
          ''')

    eleccion = int(input())

    if eleccion == 1 and gradosFahrenheit:
        print("Tu conversion de grados Fahrenheit a Celsisus es ", convertirACelsius(gradosFahrenheit))

    if eleccion == 2 and gradosCelsius:
        print("Tu conversion de grados Celsisus a Fahrenheit es ", convertirAFahrenheit(gradosCelsius))    

    if eleccion == 3:
        print('Ingrese nuevos valores')
        gradosFahrenheit = int(input("Ingrese el valor: "))
        gradosCelsius = int(input("Ingrese el valor: "))

    if eleccion == 4:
        print('Gracias por pararme bola. Bye')
