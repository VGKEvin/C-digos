import pygame, sys
from pygame.locals import *

# Configuración pygame.
pygame.init()

# Configurar la ventana.
superficieVentana = pygame.display.set_mode((500, 400), 0, 32)
pygame.display.set_caption('¡ALEX ASI SE LA COME!')

# Configurar los colores.
NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)
ROJO = (255, 0, 0)
VERDE = (0, 255, 0)
AZUL = (0, 0, 255)
CAFE = (123, 22, 0)

# Configurar la fuente.
fuenteBasica = pygame.font.SysFont(None, 48)

# Configurar el texto.
texto = fuenteBasica.render('¡ALEX ASI SE LA COME!', True, BLANCO, AZUL)
textRect = texto.get_rect()
textRect.centerx = superficieVentana.get_rect().centerx
textRect.centery = superficieVentana.get_rect().centery

# Pintar un fondo blanco sobre la ventana.
superficieVentana.fill(BLANCO)

# Dibujar un polígono verde sobre la superficie
pygame.draw.polygon(superficieVentana, VERDE, ((146, 0), (291, 106), (236, 277), (56, 277), (0, 106)), 5)


# Dibujar algunas líneas azules sobre la superficie.
pygame.draw.polygon(superficieVentana, CAFE, ((40, 100), (120, 100), (120, 130), (40, 130)))
pygame.draw.polygon(superficieVentana, CAFE, ((60, 100), (100, 100), (100, 30), (60, 30), (60, 100)))
pygame.draw.polygon(superficieVentana, ROJO, ((50, 30), (110, 30), (110, 10), (50, 10), (50, 30)), 5)
pygame.draw.polygon(superficieVentana, NEGRO, ((70, 20), (90, 20), (90, 10), (70, 10), (70, 20)), 4)

# Las venas para la polla
pygame.draw.line(superficieVentana, NEGRO, (60, 100), (70, 80), 2)
pygame.draw.line(superficieVentana, NEGRO, (80, 60), (100, 80), 3)
pygame.draw.line(superficieVentana, NEGRO, (60, 50), (80, 50), 2)
pygame.draw.line(superficieVentana, NEGRO, (80, 30), (100, 50), 3)

# Separador de las bolas
pygame.draw.line(superficieVentana, NEGRO, (80, 130), (80, 100), 2)
pygame.draw.line(superficieVentana, NEGRO, (60, 100), (100, 100), 2)

# Dibujar un circulo sobre la superficie.
pygame.draw.circle(superficieVentana, AZUL, (300, 50), 20, 0)

# Dibujar una elipse roja sobre la superficie.
pygame.draw.ellipse(superficieVentana, ROJO, (300, 250, 40, 80), 1)

# Dibujar el rectángulo de fondo para el texto sobre la superficie.
pygame.draw.rect(superficieVentana, ROJO, (textRect.left - 20, textRect.top - 20, textRect.width + 40, textRect.height + 40))

# Dibujar un arreglo de pixeles de la superficie.
arregloDePixeles = pygame.PixelArray(superficieVentana)
arregloDePixeles[480][380] = NEGRO
del arregloDePixeles

# Dibujar el texto sobre la superficie.
superficieVentana.blit(texto, textRect)

# Dibujar la ventana sobre la pantalla.
pygame.display.update()

# Ejecutar el bucle del juego.
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit
                 
                    
