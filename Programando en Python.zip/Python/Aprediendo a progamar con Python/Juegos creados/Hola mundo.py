# Este programa me ayuda aprender a como saludar
print('Hola Mundo')
print('¿Cómo te llamas?')
Metyas = input()
print('Es un placer conocerte, ' + Metyas)
print('¿Qué estas haciendo, ' + Metyas)
