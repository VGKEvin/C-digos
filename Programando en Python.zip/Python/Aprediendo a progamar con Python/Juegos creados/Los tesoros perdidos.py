# Los Tesoros Perdidos

import random
import sys

def dibujarTablero(tablero):
    #Dibuja la estructura de datos del tablero.

    lineah = '   '# Espacio inicial para los números a los largo del lado izquierdo del tablero.
    for i in range(1, 6):
        lineah += (' ' * 9) + str(i)

    # Imprimir los números a lo largo de borde superior.
    print(lineah)
    print('   ' + ('0123456789' * 6))
    print()

    # Imprimir cada una de las 15 filas
    for i in range(15):
        # Los números de una sola cifra deben ser precedidos por un espacio extra.
        if i < 10:
            espacioExtra = ' '
        else:
            espacioExtra = ''
        print('%s%s %s %s' % (espacioExtra, i, obtenerFila(tablero, i), i))

    # Imprimir los números a lo largo del borde inferior.
    print()
    print('   ' + ('0123456789' * 6))
    print(lineah)


def obtenerFila(tablero, fila):
    # Devuelve una cadena con la estructura de datos de un tablero para una fila determinada.
    filaTablero = ''
    for i in range(60):
        filaTablero += tablero[i][fila]
    return filaTablero

def obtenerNuevoTablero():
    # Crear una nueva estructura de datos para un tablero de 60x15.
    tablero = []
    for x in range(60): # La lista principal es una lista de 60 listas.
        tablero.append([])
        for y in range(15): # Cada lista en la fila principal tiene 15 cadenas de un solo caracter.
            # Usar diferentes caracteres para el océano para hacerlo mas fácil de leer.
            if random.randint(0, 1) == 0:
                tablero[x].append('~')
            else:
                tablero[x].append('`')
    return tablero

def obtenerCofresAleatorios(numCofres):
    # Crear una lista de estructuras de datos cofre (listas de dos ítems con coordenadas x, y).
    cofres = []
    for i in range(numCofres):
        cofres.append([random.randint(0, 59), random.randint(0, 14)])
    return cofres

def esMovidaVálida(x, y):
    # Devuelve True (Verdadero) si las coordenadas pertenecen al tablero, de lo contrario False (Falso).
    return x >= 0 and x <= 59 and y >=0 and y <= 14

def realizarMovida(tablero, cofres, x, y):
    # Cambia la estructura de datos del tablero agregando un caracter de dispositivo a encontrar. Elimina los cofres.
    # De la lista de cofres a medida que son encontrados. Devuelve False si la movida es válida.
    # En caso contrario, devuelve una cadena con el resultado de esa móvida.
    if not esMovidaVálida(x, y):
        return False

    menorDistancia = 100 # Cualquier cofre estará a una distancia menor que 100.
    for cx, cy in cofres:
        if abs(cx - x) > abs(cy - y):
            distancia = abs(cx - x)
        else:
            distancia = abs(cy - y)

        if distancia < menorDistancia: # Queremos el cofre más cercano.
            menorDistancia = distancia

    if menorDistancia == 0:
        # ¡xy está directamente sobre un cofre!
        tablero.remove([x, y])
        return '¡Has encontrado un cofre del tesoro hundido'
    else:
        if menorDistancia < 10:
            tablero[x][y] = str(menorDistancia)
            return 'Tesoro detectado a una distancia %s del dispositivo sonar.' % (menorDistancia)
        else:
            tablero[x][y] = '0'
            return 'El dispositivo no ha detectado nada. Todos los cofres están fuera del alcance del dispositivo.'


def ingresarMovidaJugador():
    # Permite al jugador teclear su movida. Devuelve una lista de dos ítems con coordenas xy.
    print('¿Dónde quieres dejar caer el siguiente dispositivo para detectar el tesoro? (0 - 59 0-14) (o tecla salir)')
    while True:
        movida = input()
        if movida.lower() == 'salir':
            print('¡Gracias por jugar!')
            sys.exit()

        movida = movida.split()
        if len(movida) == 2 and movida[0].isdigit() and movida[1].isdigit() and esMovidaVálida(int(movida[0]), int(movida[1])):
            return [int(movida[0]), int(movida[1])]
        print('Ingresa un número de 0 a 59, un espacio, y luego un número de 0 a 14')


def jugarDeNuevo():
    # Esta función devuelve True (Verdadero) si el jugador quiere jugar de nuevo, de lo contario devuelve False (Falso).
    print('¿Quieres jugar de nuevo? (Sí/No)')
    return input().lower().startswith('s')


def mostrarIntroducciones():
    print('''Introducciones:
Eres el capitán de Simón, un buque cazador de tesoros. Tu misión actual
es encontrar los tres cofres con tesoros perdidos que se hallan ocultos en
la parte del oceano en que te encuntras y recogerlos.

Para jugar, ingresa las coordenadas del punto del océano en que quieres
colocar un dispositivo a sonar. Al sonar puede detectar cuál es la distancia al cofre más cercano.
Por ejemplo, la 'D' de abajo indica dónde se ha colocado el dispositivo, y los
números 2 representan los sitios a una distancia 2 del dispositivo. Los
números 4 representan los sitios a una distancia 4 del dispositivo.

    444444444
    4       4
    4 22222 4
    4 2   2 4
    4 2 D 2 4
    4 2   2 4
    4 22222 4
    4       4
    444444444
Pulsar enter para continuar...''')
    input()

    print('''Por ejemplos, aquí hay un cofre del tesoro (la c) ubicado a una distancia
2 del dispositivo que suena (la d):

    22222
    c   2
    2 d 2
    2   2
    22222

El punto donde el dispositivo fue colocado se indicará con una d.

Los cofres del tesoro se mueven. Los dispositivos que suenan pueden detectar
cofres hasta una distancia 9. Si todos los cofres están fuera del alcance.
el punto se indicará con una 0.

Si un dispositivo es colocado directamente sobre un cofre del tesoro, has
descubierto la ubicación del cofre, y este será recogido. El dispositivo
que suena permanecera allí.

Cuando recojas un cofre, todos los dispositivos que suenan se actualizarán para
localizar el próximo cofre hundido más cercano.
Pulsa enter para continuar...''')
    input()
    print()


print('¡ S O N A R !')
print()
print('¿Te gustaría ver las intrucciones? (Sí/No)')
if input().lower().startswith('s'):
    mostrarIntroducciones()

while True:
    # Configuración del juego.
    dispositivosSonar = 16
    elTablero = obtenerNuevoTablero()
    losCofres = obtenerCofresAleatorios(3)
    dibujarTablero(elTablero)
    movidasPrevias = []

    while dispositivosSonar > 0:
        # Comienzo de un turno:

        # Mostrar el estado de los dispositivos sonar / cofres
        if dispositivosSonar > 1: extraSsonar = 's'
        else: extraSsonar = ''
        if len(losCofres) > 1: extraScofre = 's'
        else: extraScofre = ''
        print('Aún tienes %s dispositivo%s que suenan. Falta encontrar %s cofre%s.' % (dispositivosSonar, extraSsonar, len(losCofres), extraScofre))

        x, y = ingresarMovidaJugador()
        movidasPrevias.append([x, y]) # Debemos registar todas las movidas para que los dispositivos que suenan puedan ser actualizados.

        resultadoMovida = realizarMovida(elTablero, losCofres, x, y)
        if resultadoMovida == False:
            continue
        else:
            if resultadoMovida == '¡Has encontrado uno de los cofres del tesoro!':
                # Actulizar todos los dispositivos presentes en el mapa.
                for x, y in movidasPrevias:
                    realizarMovida(elTablero, losCofres, x, y)
            dibujarTablero(elTablero)
            print(resultadoMovida)

        if len(losCofres) == 0:
            print('¡Has encontrado todos los cofres del tesoro! ¡Felicitaciones, eres muy inteligente!')
            break

        dispositivosSonar -= 1

    if dispositivosSonar == 0:
        print('¡Nos hemos quedado sin dispositivos! ¡Ahora tenemos que dar la vuelta y dirigirnos')
        print('de regreso a casa dejando tesoros en el mar! Juego terminado.')
        print('    Los cofres restantes estaban aquí:')
        for x, y in losCofres:
            print('    %s, %s' % (x, y))

    if not jugarDeNuevo():
        sys.exit()

        

    
            
            


        
    
