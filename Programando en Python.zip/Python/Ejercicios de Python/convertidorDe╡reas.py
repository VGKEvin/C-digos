# Funciones con sus formulas acerca del area, perimetro, volumen y superficie.
def area(largo, ancho):
    return largo * ancho

def perimetro(lago, ancho):
    return largo + ancho + largo + ancho

def volumen(largo, ancho, alto):
    return largo * ancho * alto

def superficie(largo, ancho, alto):
    return ((largo * ancho) + (largo * alto) + (ancho * alto)) * 2 

eleccion = 0

# Bienvenida del programa.
print('''Bienvenido al programa para saber el area, el perimetro,
      el volumen y la superficie de una figura''')
print('''Comienza diciendome las medidas del lagro, ancho y alto
      de tu figura''')
# El usuario ingresara las medidas de su figura.
largo = int(input("Largo = "))
ancho = int(input("Ancho = "))
alto = int(input("Largo = "))           
print('Muy bien. Ahora seleccion que deseas saber sobre tu figura')

while eleccion != 6:
    print('''
         1) Área
         2) Perimetro
         3) Volumen
         4) Superficie
         5) Cambiar valores de la figura
         6) Salir del programa
         ''')

    eleccion = int(input())

    if eleccion == 1 and largo and ancho:
        print("El área de tu figura mide ", area(largo, ancho))

    if eleccion == 2 and largo and ancho:
        print("El perimetro de tu figure mide ", perimetro(largo, ancho))

    if eleccion == 3 and largo and ancho and alto:
        print("El volumen de tu figura mide ", volumen(largo, ancho, alto))

    if eleccion == 4 and largo and ancho and alto:
        print("La superficie de tu figura mide ", superficie(largo, ancho, alto))

    if eleccion == 5:
        largo = int(input("Largo = "))
        ancho = int(input("Ancho = "))
        alto = int(input("Largo = "))

    if eleccion == 6:
        print("Gracias por haber utilizado el programa ¡Un fuerte saludo!")
           

