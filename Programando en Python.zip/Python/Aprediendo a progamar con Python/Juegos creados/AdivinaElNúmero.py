# Juego de adivinar el número
import random

intentosRealizados = 0

print ('!Hola! ¿Cómo te llamas?')
Nombre = input()

número = random.randint(1, 20)
print('Bueno, ' + Nombre + ' , estoy pensando un numero del 1 al 20')
print('¿Crees poder adivinarnlo?')
respuesta = input()
    
while intentosRealizados < 6:
    print('Intenta adivinar')
    estimación = input()
    estimación = int(estimación)

    intentosRealizados = intentosRealizados + 1

    if estimación < número:
        print('Tu estimación es muy baja.')

    if estimación > número:
        print('Tu estimacion es muy alta.')

    if estimación == número:
        break

if estimación == número:
    intentosRealizados = str(intentosRealizados)
    print('Buen trabajo, ' + Nombre + ' !Has adivinado mi número en ' + intentosRealizados + ' intentos!')

if estimación != número:
    número = str(número)
    print('Pues no. El número que estaba pensando era el ' + número)
