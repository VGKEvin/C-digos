# Atrapador

import random
import sys

def dibujarTablero(tablero):
    # Está función dibuja el tablero recibido. Devuelve None.
    LINEAH = '  +---+---+---+---+---+---+---+---+'
    LINEAV = '  |   |   |   |   |   |   |   |   |'

    print('    1   2   3   4   5   6   7   8')
    print(LINEAH)
    for y in range(8):
        print(LINEAV)
        print(y+1, end=' ')
        for x in range(8):
            print('| %s' % (tablero[x][y]), end=' ')
        print('|')
        print(LINEAV)
        print(LINEAH)


def reiniciarTablero(tablero):
    # Deja en blanco al tablero recibido como argumento, excepto la posicion inicial.
    for x in range(8):
        for y in range(8):
            tablero[x][y] = ' '

    # Piezas iniciales:
    tablero[3][3] = 'X'
    tablero[3][4] = 'O'
    tablero[4][3] = 'O'
    tablero[4][4] = 'X'


def obtenerNuevoTablero():
    # Crea un tablero nuevo, vacío.
    tablero = []
    for i in range(8):
        tablero.append([' '] * 8)

    return tablero


def esJugadaValida(tablero, baldosa, comienzoX, comienzoY):
    # Devuelve False si la jugada del jugador en comienzoX, comienzoY es invalida.
    # Si es un jugada válida, devuelve una lista de espacios que pasarían a ser del jugador si moviera aquí.
    if tablero[comienzoX][comienzoY] != ' ' or not estaEnTablero(comienzoX, comienzoY):
        return False

    tablero[comienzoX][comienzoY] = baldosa # Coloca por cierto tiempo la baldosa sobre el tablero.

    if baldosa == 'X':
        otraBaldosa = 'O'
    else:
        otraBaldosa = 'X'

    baldosasAConvertir = []
    for direccionx, direcciony in [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]:
        x, y = comienzoX, comienzoY
        x += direccionx # Primer paso en la dirección
        y += direcciony # Primer paso en la dirección
        if estaEnTablero(x, y) and tablero[x][y] == otraBaldosa:
            # Hay una pieza perteneciente al otro jugador al lado de nuestra pieza.
            x += direccionx
            y += direcciony
            if not estaEnTablero(x, y):
                continue
            while tablero[x][y] == otraBaldosa:
                x += direccionx
                y += direcciony
                if not estaEnTablero(x, y): # Sale del bucle while y continua en el bucle for.
                    break
            if not estaEnTablero(x, y):
                continue
            if tablero[x][y] == baldosa:
                # Hay fichas a convertir. Cambiar una direccion opuesta hasta llegar al casillero original, registrando todas las posiciones en el camino.
                while True:
                    x -= direccionx 
                    y -= direcciony
                    if x == comienzoX and y == comienzoY:
                        break
                    baldosasAConvertir.append([x, y])

    tablero[comienzoX][comienzoY] = ' ' # Reestablecer el espacio vacío
    if len(baldosasAConvertir) == 0: # Si no se convertió ninguna baldosa, la jugada no es válida.
        return False
    return baldosasAConvertir


def estaEnTablero(x, y):
    # Devuelve True (Verdadero) si las coordenadas se encuntran dentro del tablero.
    return x >= 0 and x <= 7 and y >= 0 and y <= 7


def obtenerTableroConJugadasValidas(tablero, baldosa):
    # Devuelve un nuevo tablero, marcando con "." las jugadas válidas que el jugador puede llegar a realizar.
    replicaTablero = obtenerCopiaTablero(tablero)

    for x, y in obtenerJugadasValidas(replicaTablero, baldosa):
        replicaTablero[x][y] = '.'
    return replicaTablero


def obtenerJugadasValidas(tablero, baldosa):
    # Devuelve una lista de listas [x, y] de jugadas válidas para el jugador en el tablero dado.
    jugadasValidas = []

    for x in range(8):
        for y in range(8):
            if esJugadaValida(tablero, baldosa, x, y) != False:
                jugadasValidas.append([x, y])
    return jugadasValidas


def obtenerPuntajeTablero(tablero):
    # Determina el puntaje contando las piezas. Devuelve un diccionario con clave 'X' y 'O'.
    puntajex = 0
    puntajeo = 0
    for x in range(8):
        for y in range(8):
            if tablero[x][y] == 'X':
                puntajex += 1
            if tablero[x][y] == 'O':
                puntajeo += 1
    return {'X':puntajex, 'O':puntajeo}


def ingresarBaldosaJugador():
    # Permite al jugador elegir que baldosa desea ser.
    # Devuelve una lista con la baldosa del jugador como primer elemento y el de la computadora como segundo.
    baldosa = ''
    while not (baldosa == 'X' or baldosa == 'O'):
        print('¿Deseas ser X u O?')
        baldosa = input().upper()

    # El primer elemento en la lista es la baldosa del jugador, el segundo es de la computadora.
    if baldosa == 'X':
        return ['X', 'O']
    else:
        return ['O', 'X']


def quienComienza():
    # Elije al azar el jugador que va comenzar la partida.
    if random.randint(0, 1) == 0:
        return 'La computadora'
    else:
        return 'El jugador'


def jugarDeNuevo():
    # Está función devuelve True (Verdadero)) sí el jugador quiere jugar de nuevo, de lo contrario devuelve False
    print('¿Quieres jugar de nuevo? (Sí/No)')
    return input().lower().startswith('s')


def hacerJugada(tablero, baldosa, comienzoX, comienzoY):
    # Coloca la baldosa sobre el tablero en comienzoX, comienzoY, y convierte cualquier baldosa del oponente.
    # Devuelve False (Falso) si la jugada es inválida, True (Verdadero) si es válida.
    baldosasAConvertir = esJugadaValida(tablero, baldosa, comienzoX, comienzoY)

    if baldosasAConvertir == False:
        return False

    tablero[comienzoX][comienzoY] = baldosa
    for x, y in baldosasAConvertir:
        tablero[x][y] = baldosa
    return True


def obtenerCopiaTablero(tablero):
    # Duplica la lista del tablero y devuelve el duplicado.
    replicaTablero = obtenerNuevoTablero()

    for x in range(8):
        for y in range(8):
            replicaTablero[x][y] = tablero[x][y]

    return replicaTablero


def esEsquina(x, y):
    # Devuelve True (Verdadero) sí la posición es una de las esquinas.
    return (x == 0 and y == 0) or (x == 7 and y == 0) or (x == 0 and y == 7) or (x == 7 and y == 7)


def obtenerJugadaJugador(tablero, baldosaJugador):
    # Permite al jugador tipear su jugada.
    # Devuelve la jugada como [x, y] (o devuelve las cadenas 'pistas' o 'salir').
    CIFRAS1A8 = '1 2 3 4 5 6 7 8'.split()
    while True:
        print('Ingresa tu jugada, salir para terminar el juego, o pistas para activar/desactivar las pistas.')
        jugada = input().lower()
        if jugada == 'salir':
            return 'salir'
        if jugada == 'pistas':
            return 'pistas'

        if len(jugada) == 2 and jugada[0] in CIFRAS1A8 and jugada[1] in CIFRAS1A8:
            x = int(jugada[0]) - 1
            y = int(jugada[1]) - 1
            if esJugadaValida(tablero, baldosaJugador, x, y) == False:
                continue
            else:
                break
        else:
            print('Esta no es una jugada válida. Ingresa la coordenada x (1-8), luego la coordenas(1-8).')
            print('Por ejemplo, 81 representa la esquina superior derecha.')

    return [x, y]


def obtenerJugadaC(tablero, baldosaC):
    # Dado un tablero y la baldosa de la computadora, determinar dónde jugar y devolver esa jugada como uns lista [x, y].
    jugadasPosibles = obtenerJugadasValidas(tablero, baldosaC)

    # Ordenar al azar el orden de las jugadas posibles.
    random.shuffle(jugadasPosibles)

    # Siempre jugar en una esquina si está disponible.
    for x, y in jugadasPosibles:
        if esEsquina(x, y):
            return [x, y]

    #Recorrer la lista de jugadas posibles y recordar la que da el mejor puntaje.
    mejorPuntaje = -1
    for x, y in jugadasPosibles:
        replicaTablero = obtenerCopiaTablero(tablero)
        hacerJugada(replicaTablero, baldosaC, x, y)
        puntaje = obtenerPuntajeTablero(replicaTablero)[baldosaC]
        if puntaje > mejorPuntaje:
            mejorJugada = [x, y]
            mejorPuntaje = puntaje
    return mejorJugada


def mostrarPuntajes(baldosaJugador, baldosaC):
    # Imprime el puntaje actual.
    puntajes = obtenerPuntajeTablero(tableroPrincipal)
    print('Tienes %s puntos. La computadora tiene %s punto.' % (puntajes[baldosaJugador], puntajes[baldosaC]))



print('Bienvenido al Atrapador')

victoriasX = 0
victoriasO = 0
empates = 0
numPartidas = int(input('Ingresa el número de partidas a jugar: '))

for partida in range(numPartidas):
    print('Partida %s:' % (partida), end=' ')
    # Reiniciar el tablero y partida.
    tableroPrincipal = obtenerNuevoTablero()
    reiniciarTablero(tableroPrincipal)
    if quienComienza() == 'jugador':
        turno = 'X'
    else:
        turno = 'O'

    while True:
        if turno == 'X':
            # Turno para X.
            otraBaldosa = 'O'
            x, y = obtenerJugadaC(tableroPrincipal, 'X')
            hacerJugada(tableroPrincipal, 'X', x, y)
        else:
            # Turno para O
            otraBaldosa = 'X'
            x, y = obtenerJugadaC(tableroPrincipal, 'O')
            hacerJugada(tableroPrincipal, 'O', x, y)

        if obtenerJugadasValidas(tableroPrincipal, otraBaldosa) == []:
            break
        else:
            turno = otraBaldosa

    # Mostrar el puntaje final.
    puntajes = obtenerPuntajeTablero(tableroPrincipal)
    print('X ha obteneido %s puntos. O ha obtenido %s puntos' % (puntajes['X'], puntajes['O']))

    if puntajes['X'] > puntajes['O']:
        victoriasX += 1
    elif puntajes['X'] < puntajes['O']:
        victoriasO += 1
    else:
        empates += 1

numPartidas = float(numPartidas)
porcentajeX = round(((victoriasX / numPartidas) * 100), 2)
porcentajeO = round(((victoriasO / numPartidas) * 100), 2)
porcentajeEmpates = round(((empates / numPartidas) * 100), 2)
print('X ha ganado %s partidas (%s%%), O ha ganado %s partidas (%s%%), empates en %s partidas(%s%%) sobre un total de %s partidas.' % (victoriasX, porcentajeX, victoriasO, porcentajeO, empates, porcentajeEmpates, numPartidas))
            
        


            
            
                      

                
            
            
            
        


            
