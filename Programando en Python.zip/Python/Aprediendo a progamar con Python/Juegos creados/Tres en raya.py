# Tres en raya

import random

def dibujarTablero(tablero):
    # Esta función dibuja el tablero recibido como argumento.

    # "tablero" es una lista de 10 cadenas representando en la pizarra(ignora el indice 0).
    print('   |   |')
    print(' ' + tablero[7] + ' | ' + tablero[8] + ' | ' + tablero[9])
    print('   |   |')
    print('-----------')
    print('   |   |')
    print(' ' + tablero[4] + ' | ' + tablero[5] + ' | ' + tablero[6])
    print('   |   |')
    print('-----------')
    print('   |   |')
    print(' ' + tablero[1] + ' | ' + tablero[2] + ' | ' + tablero[3])
    print('   |   |')

def ingresaLetraJugador():
    # Permite a el jugador elegir cual letra quiere ser.
    # Devuelve una lista con las letras de los jugadores como primer item, y la computadora como segundo.
    letra = ''
    while not (letra == 'X' or letra == 'O'):
        print('¿Deseas ser X u O?')
        letra = input().upper()

    # El primer elemento de la lista es la letra del jugador, el segundo es la letra de la computadora.
    if letra == 'X':
        return ['X', 'O']
    else:
        return ['O', 'X']

def quienComienza():
    # Elije al azar que jugador va comenzar la partida.
    if random.randint(0, 1) == 0:
        return 'La computadora'
    else:
        return 'El jugador'

def jugarDeNuevo():
    # Esta función devuelve True (Verdadero) si el jugador desea volver a jugar, de lo contrario devuelve False (Falso).
    print('¿Deseas volver a jugar? (si ó no)')
    return input().lower().startswith('s')

def hacerJugada(tablero, letra, jugada):
    tablero[jugada] = letra

def esGanador(ka, ke):
    # Dado un tablero y la letra del jugador, devuelve True (Verdadero) si el mismo ha ganado.
    # Reemplazamos en el tablero por la letra "ka" y la letra "ke" para no escribir tanto.
    return ((ka[7] == ke and ka[8] == ke and ka[9] == ke) or # Horizontal superior.
    (ka[4] == ke and ka[5] == ke and ka[6] == ke) or # Horizontal medio.
    (ka[1] == ke and ka[2] == ke and ka[3] == ke) or # Horizontal inferior.
    (ka[7] == ke and ka[4] == ke and ka[1] == ke) or # Vertical izquierda.
    (ka[8] == ke and ka[5] == ke and ka[2] == ke) or # Vertical medio.
    (ka[9] == ke and ka[6] == ke and ka[3] == ke) or # Vertical derecha.
    (ka[7] == ke and ka[5] == ke and ka[3] == ke) or # Diagonal.
    (ka[9] == ke and ka[5] == ke and ka[1] == ke)) # Diagonal.

def obtenerDuplicadoTablero(tablero):
    # Duplica la lista del tablero y devuelve el duplicado.
    dupTablero = []

    for i in tablero:
        dupTablero.append(i)

    return dupTablero

def hayEspacioLibre(tablero, jugada):
    # Devuelve true si hay espacio para realizar la jugada en el tableo.
    return tablero[jugada] == ' '

def obtenerJugadaJugador(tablero):
    # Permite al jugador escribir su jugada.
    jugada = ' '
    while jugada not in '1 2 3 4 5 6 7 8 9'.split() or not hayEspacioLibre(tablero, int(jugada)):
        print('¿Cuál es tu próxima jugada? (1-9)')
        jugada = input()
    retaaurn int(jugada)

def elegirAzarDeLista(tablero, listaJugada):
    # Devuelve una jugada válida en el tablero de la lista recibida.
    # Devuelve "None" si no hay ninguna jugada válida.
    jugadaPosibles = []
    for i in listaJugada:
        if hayEspacioLibre(tablero, i):
            jugadaPosibles.append(i)

    if len(jugadaPosibles) != 0:
        return random.choice(jugadaPosibles)
    else:
        return None

def obtenerJugadaC(tablero, letraC):
    # Dado un tablero y la letra de C (Computadora), determina que jugada realizar.
    if letraC == 'X':
        letraJugador = 'O'
    else:
        letraJugador = 'X'

    # Aquí está nuestro algoritmo para nuestra IA (Inteligencia Artifial) del tres en raya.
    # Primero, verifica si podemos ganar la próxima jugada.
    for i in range(1, 10):
        copia = obtenerDuplicadoTablero(tablero)
        if hayEspacioLibre(copia, i):
            hacerJugada(copia, letraC, i)
            if esGanador(copia, letraC):
                return i

    # Verifica si el jugador podría ganar en su próxima jugada, y lo bloquea.
    for i in range(1, 10):
        copia = obtenerDuplicadoTablero(tablero)
        if hayEspacioLibre(copia, i):
            hacerJugada(copia, letraJugador, i)
            if esGanador(copia, letraJugador):
                return i

    # Intenta ocupar una de las esquinas libre.
    jugada = elegirAzarDeLista(tablero, [1, 3, 7, 9])
    if jugada != None:
        return jugada

    # De estar libre, intenta ocupar el centro.
    if hayEspacioLibre(tablero, 5):
        return 5

    # Ocupa alguno de los lados.
    return elegirAzarDeLista(tablero, [2, 4, 6, 8])

def tableroCompleto(tablero):
    # Devuelve True (Verdadero) si cada espacio del tablero fue ocupado, caso contrario devuelve False (Flaso).
    for i in range(1, 10):
        if hayEspacioLibre(tablero, i):
            return False
    return True


print('¡Bienvenido a Tres en raya!')
print('Para tener una mejor experiencia, juega con el teclado númerico del taclado')
print('Así no tendras complicaciones en confundirte al jugar')
print('¡Suerte!')
      
while True:
    # Resetea el tablero.
    elTablero = [' '] * 10
    letraJugador, letraC = ingresaLetraJugador()
    turno = quienComienza()
    print(turno + ' irá primero.')
    juegoEnCurso = True

    while juegoEnCurso:
        if turno == 'El jugador':
            # Turno del jugador.
            dibujarTablero(elTablero)
            jugada = obtenerJugadaJugador(elTablero)
            hacerJugada(elTablero, letraJugador, jugada)

            if esGanador(elTablero, letraJugador):
                dibujarTablero(elTablero)
                print('¡Felicidades, has ganado!')
                juegoEnCurso = False
            else:
                if tableroCompleto(elTablero):
                    dibujarTablero(elTablero)
                    print('¡Es un empate!')
                    break
                else:
                    turno = 'La computadora'

        else:
            # Turno de la computadora.
            jugada = obtenerJugadaC(elTablero, letraC)
            hacerJugada(elTablero, letraC, jugada)

            if esGanador(elTablero, letraC):
                dibujarTablero(elTablero)
                print('¡La computadora te ha vencido! ¡NOOB!')
                juegoEnCurso = False
            else:
                if tableroCompleto(elTablero):
                    dibujarTablero(elTablero)
                    print('¡Es un empate!')
                    break
                else:
                    turno = 'El jugador'

    if not jugarDeNuevo():
        break
                

    
    
