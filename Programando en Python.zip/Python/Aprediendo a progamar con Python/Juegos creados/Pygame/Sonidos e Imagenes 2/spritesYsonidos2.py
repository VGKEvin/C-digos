import pygame, sys, time, random
from pygame.locals import *

# Configurar pygame.
pygame.init()
relojPrincipal = pygame.time.Clock()

# Configurar la ventana.
ANCHOVENTANA = 1366
ALTOVENTANA = 768
superficieVentana = pygame.display.set_mode((ANCHOVENTANA, ALTOVENTANA), 0, 32)
pygame.display.set_caption('Sprites y Sonidos')

# Configurar los colores.
NEGRO = (0, 0, 0)

# Configurar la estructura de bloque de datos.
jugador = pygame.Rect(300, 100, 40, 40)
imagenJugador = pygame.image.load('mike.png')
imagenEstiradaJugador = pygame.transform.scale(imagenJugador, (40, 40))
imagenComida = pygame.image.load('pan.png')
comidas = []
for i in range(20):
    comidas.append(pygame.Rect(random.randint(0, ANCHOVENTANA - 20), random.randint(0, ALTOVENTANA - 20), 20, 20))

contadorDeComida = 0
NUEVACOMIDA = 40

# Configurar variables del teclado.
moverseIzquierda = False
moverseDerecha = False
moverseArriba = False
moverseAbajo = False

VELOCIDADMOVIMIENTO = 6

# Configurar música.
sonidoRecoleccion = pygame.mixer.Sound('madera.wav')
pygame.mixer.music.load('músicaDeFondo.mid')
pygame.mixer.music.play(-1, 0.0)
musicaSonando = True

# Ejectutar el bucle del juego.
while True:
    # Comprobar si se ha disparado el evento QUIT (salir).
    for evento in pygame.event.get():
        if evento.type == QUIT:
            pygame.quit()
            sys.exit()
        if evento.type == KEYDOWN:
            # Cambiar las variables del teclado
            if evento.key == K_LEFT or evento.key == ord('a'):
                moverseDerecha = False
                moverseIzquierda = True
            if evento.key == K_RIGHT or evento.key == ord('d'):
                moverseIzquierda = False
                moverseDerecha = True
            if evento.key == K_UP or evento.key == ord('w'):
                moverseAbajo = False
                moverseArriba = True
            if evento.key == K_DOWN or evento.key == ord('s'):
                moverseArriba = False
                moverseAbajo = True
        if evento.type == KEYUP:
            if evento.key == K_ESCAPE:
                pygame.quit()
                sys.exit()
            if evento.key == K_LEFT or evento.key == ord('a'):
                moverseIzquierda = False
            if evento.key == K_RIGHT or evento.key == ord('d'):
                moverseDerecha = False
            if evento.key == K_UP or evento.key == ord('w'):
                moverseArriba = False
            if evento.key == K_DOWN or evento.key == ord('s'):
                moverseAbajo = False
            if evento.key == ord('x'):
                jugador.top = random.randint(0, ALTOVENTANA - jugador.height)
                jugador.left = random.randint(0, ANCHOVENTANA - jugador.width)
            if evento.key == ord('m'):
                if musicaSonando:
                    pygame.mixer.music.stop()
                else:
                    pygame.mixer.music.play(-1, 0.0)
                musicaSonando = not musicaSonando

        if evento.type == MOUSEBUTTONUP:
            comidas.append(pygame.Rect(evento.pos[0] - 10, evento.pos[1] - 10, 20, 20))

    contadorDeComida += 1
    if contadorDeComida >= NUEVACOMIDA:
        # Agregar nueva comida.
        contadorDeComida = 0
        comidas.append(pygame.Rect(random.randint(0, ANCHOVENTANA - 20), random.randint(0, ALTOVENTANA - 20), 20, 20))

    # Pintar el fondo negro sobre la superficie.
    superficieVentana.fill(NEGRO)

    # Mover al jugador.
    if moverseAbajo and jugador.bottom < ALTOVENTANA:
        jugador.bottom += VELOCIDADMOVIMIENTO
    if moverseArriba and jugador.top > 0:
        jugador.top -= VELOCIDADMOVIMIENTO
    if moverseIzquierda and jugador.left > 0:
        jugador.left -= VELOCIDADMOVIMIENTO
    if moverseDerecha and jugador.right < ANCHOVENTANA :
        jugador.right += VELOCIDADMOVIMIENTO


    # Dibujar el bloque sobre la superficie.
    superficieVentana.blit(imagenEstiradaJugador, jugador)

    # Comprobar si el jugador ha intersectado con alguno de los cuadrados de comida.
    for comida in comidas[:]:
        if jugador.colliderect(comida):
            comidas.remove(comida)
            jugador = pygame.Rect(jugador.left, jugador.top, jugador.width + 2, jugador.height + 2)
            imagenEstiradaJugador = pygame.transform.scale(imagenJugador, (jugador.width, jugador.height))
            if musicaSonando:
                sonidoRecoleccion.play()

    # Dibujar la comida.
    for comida in comidas:
        superficieVentana.blit(imagenComida, comida)

    # Dibujar la ventana sobre la pantalla.
    pygame.display.update()
    relojPrincipal.tick(40)
    
